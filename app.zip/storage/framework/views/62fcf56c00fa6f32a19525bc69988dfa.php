<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?php echo $__env->yieldContent('title', siteSetting()->site_title); ?></title>

    
    <link rel="icon" type="image/png" href="<?php echo e(siteSetting()->favicon_url ?? asset('favicon.ico')); ?>">

    
    <link id="pagestyle" href="<?php echo e(asset('assets/css/argon-dashboard.min28b5.css?v=2.0.0')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/js/plugins/toastr.min.css')); ?>" rel="stylesheet">
</head>

<body class="g-sidenav-show">
    <?php echo $__env->yieldContent('content'); ?>

    
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/toastr.min.js')); ?>"></script>

    <script>
        document.addEventListener("livewire:init", () => {
            // Default Toastr options
            toastr.options = {
                closeButton: true,
                progressBar: true,
                timeOut: 5000,
                positionClass: "toast-top-right",
            };

            // Listen for Livewire toast event
            Livewire.on("toast", (event) => {
                if (event.notify && event.message) {
                    toastr[event.notify](event.message);
                } else {
                    console.warn("Toast event missing 'notify' or 'message'.", event);
                }
            });
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\kahadhr-hrm-backend\resources\views/components/layouts/login_layout.blade.php ENDPATH**/ ?>