<?php

namespace App\Livewire\Backend\Components;

use Livewire\Component;

class Header extends Component
{
    public function render()
    {
        return view('livewire.backend.components.header');
    }
}
