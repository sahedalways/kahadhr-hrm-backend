<?php

namespace App\Livewire\Backend\Components;

use Livewire\Component;
use App\Traits\ToastTrait;

class BaseComponent extends Component
{
  use ToastTrait;
}
