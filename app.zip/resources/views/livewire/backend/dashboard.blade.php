@section('title', siteSetting()->site_title)

<div>
    <div class="row" wire:poll.60s>
        <div class="col-lg-12">
            <div class="row mt-5 g-4">


            </div>
        </div>
    </div>
</div>
